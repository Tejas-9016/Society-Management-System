# Society-Management-System
Society Management System is a Website which is provided to society members who can get all the updates related to their society. The members also get notified with notices and events held in society and  can see information about members in society. Members can also post complaints regarding any  issue in society. The only admin has right to modify the database which holds information of  members. Also, the admin can perform tasks that are done by the normal members of this  system.

To run project on your Desktop/laptop follow below given steps:-
1. Install XAMPP on your System.
2. Download the zip file from repository and extract it on your system.
3. Move all your Downloaded files to htdocs under xampp folder.
4. Run login.html file and project is successfully ready to use...!!

Admin login Details:-

Username:- Admin

Admin Code:- 100

For databases you need PhpMyadmin,create databases as per your need.(Refer database daigram in documention Folder.)

For more details and Screenshot Refer Documention Folder PDF..!!

Enjoy the Project..!!!
